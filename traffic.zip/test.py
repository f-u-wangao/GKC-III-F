import cv2
import os
for i in range(1,6):
    img = cv2.imread('0_'+str(i)+'.jpg')
    img = cv2.resize(img,(128,128))
    cv2.imwrite('.\data\\0'+'\\0_'+str(i)+'.jpg',img)
    cv2.imwrite('.\data\\0'+'\\0_'+str(i)+'.jpg',img)
    cv2.imwrite('.\data\\0'+'\\0_'+str(i)+'.jpg',img)
    cv2.imwrite('.\data\\0'+'\\0_'+str(i)+'.jpg',img)
    cv2.imwrite('.\data\\0'+'\\0_'+str(i)+'.jpg',img)